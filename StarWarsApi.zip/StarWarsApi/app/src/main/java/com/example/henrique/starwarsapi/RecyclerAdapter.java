package com.example.henrique.starwarsapi;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.henrique.starwarsapi.Models.planet;

import java.util.List;

/**
 * Created by henrique on 27/02/18.
 */

public class RecyclerAdapter extends RecyclerView.Adapter<ViewHolder> {

    private List<planet> list;
    public RecyclerAdapter(List<planet> planets ){
        this.list = planets ;

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        planet planet = list.get(position);

        String population = String.format("Population: %s.",planet.population);

        holder.planetName.setText(planet.name);
        holder.population.setText(population);
        holder.terrain.setText(planet.terrain);
        holder.gravity.setText(planet.gravity);
        holder.climate.setText(planet.climate);
        holder.diameter.setText(planet.diameter);
        holder.surfaceWater.setText(planet.surface_water);


    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}
