package com.example.henrique.starwarsapi.Models;

/**
 * Created by henrique on 26/02/18.
 */

public class species {

    public String name;
    public String language;
    public String classification;
    public String skin_colors;
    public String eye_colors;
    public String homeworld;

}
