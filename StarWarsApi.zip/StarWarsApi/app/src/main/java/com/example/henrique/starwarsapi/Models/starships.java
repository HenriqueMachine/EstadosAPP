package com.example.henrique.starwarsapi.Models;

/**
 * Created by henrique on 23/02/18.
 */

public class starships {

    public String name;
    public String model;
    public String manufacturer;
    public String cost_in_credits;


}
