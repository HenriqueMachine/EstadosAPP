package com.example.henrique.starwarsapi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.example.henrique.starwarsapi.Models.CallPlanet;
import com.example.henrique.starwarsapi.Models.planet;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class PlanetsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RecyclerAdapter adapter;
    private List<planet> list = new ArrayList<>();
    private List<planet> planetList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_planets);

        recyclerView = (RecyclerView) findViewById(R.id.recyclerViewPlanet);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new RecyclerAdapter(list);
        recyclerView.setAdapter(adapter);
        methodPlanets(1);
    }
    private void methodPlanets(final int page) {
        Retrofit retrofit = new Retrofit.Builder()
        .baseUrl(SwapiService.BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build();

        //polymorphism
        final SwapiService service = retrofit.create(SwapiService.class);
        final Call<CallPlanet> requestPlanet = service.listPlanets(page);

        requestPlanet.enqueue(new Callback<CallPlanet>() {
            @Override
            public void onResponse(Call<CallPlanet> call, Response<CallPlanet> response) {
                if(response.isSuccessful()){
                    Log.i("E", "Callback Success..." + response.code());
                    if (page == 1 ){
                        CallPlanet list = response.body();
                         planetList = list.results;
                        recyclerView.setAdapter(new RecyclerAdapter(planetList));
                    }else{
                        if(planetList != null){
                            //planetList.add();
                            for (planet planet : list){
                                planetList.add(planet);
                            }
                        }
                    }
                }
                /*else
                    {
                    //Requisition called successful
                    CallPlanet list = response.body();
                    List<planet> planetList = list.results;
                    recyclerView.setAdapter(new RecyclerAdapter(planetList));

                    for(planet p : list.results ){
                        Log.i("E", String.format("NAME_PLANET: %s. \n", p.name));
                        Log.i("E", "---------------");
                        String aux = String.format("Name %s \n",p.name);
                    }
                }*/
            }
            @Override
            public void onFailure(Call<CallPlanet> call, Throwable t) {
                Log.e("EE", "Error" + t.getMessage());
            }
        });
    }
}