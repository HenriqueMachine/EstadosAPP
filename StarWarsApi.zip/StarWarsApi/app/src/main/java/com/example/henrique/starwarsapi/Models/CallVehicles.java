package com.example.henrique.starwarsapi.Models;

import java.util.List;

/**
 * Created by henrique on 26/02/18.
 */

public class CallVehicles {

    public List<vehicles> results;

}
