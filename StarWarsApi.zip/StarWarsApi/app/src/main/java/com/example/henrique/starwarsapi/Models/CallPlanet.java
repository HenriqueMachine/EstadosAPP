package com.example.henrique.starwarsapi.Models;

import java.util.List;

/**
 *Created by henrique on 23/02/18.
 */

public class CallPlanet {

    public List<planet> results;

}
