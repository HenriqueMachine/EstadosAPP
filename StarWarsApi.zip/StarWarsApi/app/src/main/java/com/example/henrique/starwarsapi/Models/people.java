package com.example.henrique.starwarsapi.Models;

/**
 * Created by henrique on 23/02/18.
 */

public class people {

    public String name;
    public String gender;
    public String birth_year;
    public String homeworld;
    public String skin_color;

}
