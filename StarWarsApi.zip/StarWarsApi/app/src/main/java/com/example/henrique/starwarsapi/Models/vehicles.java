package com.example.henrique.starwarsapi.Models;

/**
 * Created by henrique on 26/02/18.
 */

public class vehicles {

    public String name;
    public String model;
    public String manufacturer;
    public String crew;
    public String cost_in_credits;
    public String consumables;
    public String max_atmosphering_speed;

}
