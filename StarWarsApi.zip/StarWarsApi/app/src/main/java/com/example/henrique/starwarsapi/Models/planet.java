package com.example.henrique.starwarsapi.Models;

/**
 * Created by henrique on 23/02/18.
 */

public class planet {

    public String name;
    public String population;
    public String climate;
    public String gravity;
    public String diameter;
    public String terrain;
    public String surface_water;

}
