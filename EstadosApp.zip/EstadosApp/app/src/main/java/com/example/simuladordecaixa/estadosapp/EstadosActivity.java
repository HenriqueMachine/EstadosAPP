package com.example.simuladordecaixa.estadosapp;


import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class EstadosActivity extends AppCompatActivity {


    private ListView listOfStates;
    private String receiveValues = "" ;
    private String [] states = {

            "São Paulo","Rio de Janeiro","Distrito Federal","Bahia","Minas Gerais",
            "Amazonas","Paraná","Santa Catarina","Rio Grande do Sul","Pará","Pernambuco",
            "Espírito Santo","Ceará","Mato Grosso","Mato Grosso do Sul","Rio Grande do Norte","Paraíba",
            "Alagoas","Sergipe","Tocantins","Piauí","Rondônia","Acre","Roraima","Amapá"

    };

    private String [] describeStates = {
            "A história de São Paulo, estado que nasceu desbravando o país e hoje abriga um mundo\n" +
                    "\n" +
                    "São Paulo possui uma história tão rica que conta a vida de uma nação, uma nação que abriga em seu território, sem exagero, características de todos os cantos do mundo. Essa história começou com um povo desbravador, bandeirante, que subiu serras e abriu florestas para marcar seu território em uma localização topográfica que, do ponto de vista da segurança, era perfeita. Atualmente a região está consolidada como uma das maiores potências econômicas e políticas do mundo, segue em pleno desenvolvimento e abriga pessoas do mundo todo.\n" +
                    "\n" +
                    "No início, São Paulo vivia da agricultura de subsistência, da tentativa de implantação em escala da lavoura de cana-de-açúcar e com o sonho da descoberta do ouro e dos metais preciosos. Começaram as viagens ao interior do país, as “bandeiras”, expedições organizadas para aprisionar índios e procurar pedras e metais preciosos nos sertões distantes.\n" +
                    "\n" +
                    "Ao longo de todo o século XVIII, São Paulo ainda era o quartel-general de onde não cessavam de partir as “bandeiras” e permanecia a pobreza em razão da carência de uma atividade econômica lucrativa. A virada na economia aconteceu na passagem do século XVIII para o XIX, quando as plantações de café substituíram as de cana-de-açúcar para ocupar o primeiro plano na economia nacional, especialmente depois que Dom Pedro declarou a Independência do Brasil, em 7 de setembro de 1822.\n" +
                    "\n" +
                    "São Paulo destacou-se no cenário nacional. A expansão da cultura do café exigiu a multiplicação das estradas de ferro. Foi um período de grandes transformações, marcado pela crise do sistema escravocrata, que levaria à Abolição em 1888 e que daria lugar, entre outros fatos, à chegada em massa de imigrantes, principal solução para a mão-de-obra na lavoura.\n" +
                    "\n" +
                    "O Estado prosperou e a capital da província passou por uma revolução urbanística e cultural. A chegada de milhares de imigrantes permitiu a ocupação do interior. Criaram-se as condições para pequenas fábricas darem início à industrialização, com o interior integrado ao crescimento da província. Novas estradas foram construídas e a prosperidade foi  sacramentada com a República.\n" +
                    "\n" +
                    "O fim do Império estava selado com a Abolição da Escravidão em 1888 e Dom Pedro II foi deposto no ano seguinte. O primeiro período republicano no Brasil, até 1930, foi controlado por São Paulo, Minas Gerais e Rio de Janeiro. A importância econômica do café de São Paulo e do gado de Minas Gerais sustentou a “política do café-com-leite”, com paulistas e mineiros se alternando na presidência da República. A ferrovia puxou a expansão da cafeicultura, atraiu imigrantes e permitiu a colonização de novas áreas.\n" +
                    "\n" +
                    "A industrialização avançava, criava novos contornos urbanos e abria espaço para novas classes sociais, o operariado e a classe média. Mais próspero do que nunca, e agora como Estado dentro da Federação, São Paulo via surgir a cada dia uma novidade diferente: a eletricidade, os primeiros carros; o crescimento das linhas de bondes elétricos e de grandes obras urbanas. Tudo se multiplicava e diversas vilas passaram a conviver com o apito das fábricas e com uma nova classe operária.\n" +
                    "\n" +
                    "A industrialização revelou o problema da geração de energia, solucionado em 1900 com a inauguração da Light. A capacidade de geração de energia foi decisiva para o desenvolvimento industrial entre 1930 e 1940. Nesse período, a aristocracia cafeeira viveu o seu apogeu. Mas a Revolução de 1930 colocou fim à liderança paulista, trazendo para o primeiro plano os Estados menores da Federação, sob a liderança do Rio Grande do Sul de Getúlio Vargas. As oligarquias paulistas promoveram a Revolução Constitucionalista em 1932, mas foram derrotadas, apesar da força econômica demonstrada.\n" +
                    "\n" +
                    "Nesta época os trilhos das ferrovias paulistas chegavam às proximidades do rio Paraná, e a colonização ocupava mais de um terço do Estado. As cidades se multiplicavam. Socialmente, o Estado, com seus mais de um milhão de imigrantes, tornou-se uma torre de Babel, profundamente marcado pelas diferentes culturas trazidas de mais de 60 países.\n" +
                    "\n" +
                    "Na última década da República Velha o modelo econômico e político mostrava seu esgotamento. Após a Revolução de 1930, o país viveu um período de instabilidade e veio a ditadura de Getúlio Vargas, que terminou com a Segunda Guerra Mundial e abriu um período de redemocratização e a instalação da chamada Segunda República.\n" +
                    "\n" +
                    "No plano econômico, o café superou a crise do início da década de 1930, favorecendo a recuperação de São Paulo. A indústria despontou e outro grande salto foi dado, com a chegada da indústria automobilística em São Paulo, carro-chefe da economia nacional a partir da década de 1950. O Estado paulista se transformou no maior parque industrial do país, posição que continuou a manter, apesar das transformações econômicas e políticas vividas pelo Brasil.","2","3","4","5",
    };

    private String [] urlYouTube = {};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_estados);

        listOfStates = findViewById(R.id.lvEstados);
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                getApplicationContext(),
                android.R.layout.simple_list_item_2,
                android.R.id.text2,
                states

        );

        listOfStates.setAdapter(adapter);

        listOfStates.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                int codePosition = position;
                int codePositionTitle = position;

                String auxToPutExtraTitle = states[codePositionTitle];

                String auxToPutExtra = describeStates[codePosition];

                Intent nextIntent = new Intent(EstadosActivity.this, DescreveEstadoActivity.class);
                finish();
                nextIntent.putExtra("Desc", auxToPutExtra);
                nextIntent.putExtra("title", auxToPutExtraTitle);
                startActivity(nextIntent);

            }
        });



    }

}
